# Ad Soyad: Bedirhan Ündoğdu Yiğit
# Öğrenci No: 20244029085
# Tarih: 22 / 11 / 2026
# Ders: Python ile Programlama - Hafta 8 Laboratuvarı
# Açıklama: 2-16 tabanları arasında iki yönlü sayı dönüşümü yapar.

RAKAM = "0123456789ABCDEF"


def onluktan(n, taban):
    # Bölme ve kalan yöntemiyle onluk doğal sayıyı hedef tabana çevirir.
    if not 2 <= taban <= 16 or n < 0:
        raise ValueError("Taban 2-16, sayı ise sıfır veya pozitif olmalı")
    if n == 0:
        return "0"
    sonuc = ""
    while n > 0:
        sonuc = RAKAM[n % taban] + sonuc
        n //= taban
    return sonuc


def onluga(metin, taban):
    # Horner yöntemiyle metindeki rakamları soldan sağa değerlendirir.
    if not 2 <= taban <= 16 or metin.strip() == "":
        raise ValueError("Taban 2-16 olmalı ve metin boş olmamalı")
    sonuc = 0
    for ch in metin.upper():
        basamak = RAKAM.find(ch)
        if basamak < 0 or basamak >= taban:
            raise ValueError(f"'{ch}' bu tabanda kullanılamaz")
        sonuc = sonuc * taban + basamak
    return sonuc


if __name__ == "__main__":
    print(f"2026 → ikilik {onluktan(2026, 2)} · sekizlik {onluktan(2026, 8)} · onaltılık {onluktan(2026, 16)}")
    print(f'onluga("7ea", 16) = {onluga("7ea", 16)}')
    print(f'onluga("11111101010", 2) = {onluga("11111101010", 2)}')
    print(f'onluga("3752", 8) = {onluga("3752", 8)}')
