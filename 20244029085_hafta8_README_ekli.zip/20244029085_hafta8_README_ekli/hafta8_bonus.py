# Ad Soyad: Bedirhan Ündoğdu Yiğit
# Öğrenci No: 20244029085
# Tarih: 22 / 11 / 2026
# Ders: Python ile Programlama - Hafta 8 Laboratuvarı
# Açıklama: Roma rakamı ile onluk tam sayı arasında iki yönlü dönüşüm.

DEGERLER = (1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
ROMALAR = ("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")


def romaya(sayi):
    # Büyükten küçüğe değer çıkararak Roma gösterimini oluşturur.
    if not 1 <= sayi <= 3999:
        raise ValueError("1-3999 arası tam sayı giriniz")
    sonuc = ""
    for i in range(len(DEGERLER)):
        while sayi >= DEGERLER[i]:
            sonuc += ROMALAR[i]
            sayi -= DEGERLER[i]
    return sonuc


def onluga(roma):
    # Roma karakterlerini ardışık okuyarak onluk değerlerini toplar.
    roma = roma.upper()
    if roma == "":
        raise ValueError("Roma sayısı boş olamaz")
    sonuc = 0
    konum = 0
    while konum < len(roma):
        if konum + 1 < len(roma) and roma[konum:konum + 2] in ("CM", "CD", "XC", "XL", "IX", "IV"):
            parca = roma[konum:konum + 2]
            adim = 2
        else:
            parca = roma[konum]
            adim = 1
        yer = ROMALAR.index(parca) if parca in ROMALAR else -1
        if yer == -1:
            raise ValueError("Geçersiz Roma karakteri")
        sonuc += DEGERLER[yer]
        konum += adim
    # Yeniden çevirerek hatalı tekrar ve dizilişleri reddeder.
    if not 1 <= sonuc <= 3999 or romaya(sonuc) != roma:
        raise ValueError("Roma rakamlarının dizilişi geçersiz")
    return sonuc


if __name__ == "__main__":
    print(f"2026 → {romaya(2026)}")
    print(f"1994 → {romaya(1994)}")
    print(f"XLII → {onluga('XLII')}")
