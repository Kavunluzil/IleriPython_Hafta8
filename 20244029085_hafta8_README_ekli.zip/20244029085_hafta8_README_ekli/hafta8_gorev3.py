# Ad Soyad: Bedirhan Ündoğdu Yiğit
# Öğrenci No: 20244029085
# Tarih: 22 / 11 / 2026
# Ders: Python ile Programlama - Hafta 8 Laboratuvarı
# Açıklama: Vigenère şifresi ile metin şifreler ve geri çözer.

ALFABE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def vigenere(metin, anahtar, yon=1):
    # Anahtarın her harfini yalnızca metindeki Latin harflerinde ilerletir.
    anahtar = anahtar.upper()
    if anahtar == "" or yon not in (1, -1):
        raise ValueError("Anahtar boş olamaz ve yön 1 ya da -1 olmalı")
    for harf in anahtar:
        if harf not in ALFABE:
            raise ValueError("Anahtar yalnızca A-Z harflerinden oluşmalı")

    sonuc = ""
    j = 0
    for karakter in metin:
        buyuk = karakter.upper()
        konum = ALFABE.find(buyuk)
        if konum == -1 or len(karakter) != 1 or karakter not in (buyuk, buyuk.lower()):
            sonuc += karakter
            continue
        kaydirma = ALFABE.find(anahtar[j % len(anahtar)])
        yeni = ALFABE[(konum + yon * kaydirma) % 26]
        sonuc += yeni if karakter == buyuk else yeni.lower()
        j += 1
    return sonuc


if __name__ == "__main__":
    sifre = vigenere("Attack at dawn", "LEMON")
    print(f'Şifreli: {sifre}')
    print(f'Çözülmüş: {vigenere(sifre, "LEMON", -1)}')
