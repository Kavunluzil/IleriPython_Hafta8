# Ad Soyad: Bedirhan Ündoğdu Yiğit
# Öğrenci No: 20244029085
# Tarih: 22 / 11 / 2026
# Ders: Python ile Programlama - Hafta 8 Laboratuvarı
# Açıklama: Türkçe alfabe düzenini kullanan TrKelime sınıfı.

ALFABE = "abcçdefgğhıijklmnoöprsştuüvyz"


class TrKelime:
    def __init__(self, metin):
        # Türkçe I ve İ özel durumlarını ele alarak metni küçültür.
        self.metin = metin.replace("I", "ı").replace("İ", "i").lower()

    def __str__(self):
        # Nesneyi kendi metni gibi gösterir.
        return self.metin

    def __len__(self):
        # Kelimenin karakter sayısını döndürür.
        return len(self.metin)

    def __getitem__(self, indeks):
        # İndeks ya da dilimle metinden karakter alır.
        return self.metin[indeks]

    def __contains__(self, parca):
        # Bir alt metnin kelimede bulunup bulunmadığını denetler.
        return parca in self.metin

    def __eq__(self, diger):
        # İki TrKelime nesnesinin normalize edilmiş metinlerini karşılaştırır.
        if not isinstance(diger, TrKelime):
            return NotImplemented
        return self.metin == diger.metin

    def __lt__(self, diger):
        # Unicode yerine Türk alfabesindeki harf konumlarını karşılaştırır.
        if not isinstance(diger, TrKelime):
            return NotImplemented
        kisa = min(len(self.metin), len(diger.metin))
        for i in range(kisa):
            sol = ALFABE.find(self.metin[i])
            sag = ALFABE.find(diger.metin[i])
            if sol == -1 or sag == -1:
                raise ValueError("Sıralama yalnızca Türk alfabesindeki harfler için yapılır")
            if sol != sag:
                return sol < sag
        return len(self.metin) < len(diger.metin)

    def buyuk(self):
        # i/ı harflerini doğru Türkçe büyük harfe çevirir.
        return self.metin.replace("i", "İ").replace("ı", "I").upper()


if __name__ == "__main__":
    for sol, sag in (("çay", "dağ"), ("ılık", "iğne"), ("ördek", "pasta")):
        print(f"{sol} < {sag}    Türkçe: {TrKelime(sol) < TrKelime(sag)}   Python str: {sol < sag}")
    print(f'TrKelime("Işık") == TrKelime("ışık") → {TrKelime("Işık") == TrKelime("ışık")}')
    k = TrKelime("İSTANBUL")
    print(f"k = {k}    len(k) → {len(k)}")
    print(f'"tan" in k → {"tan" in k}    k.buyuk() → {k.buyuk()}')
