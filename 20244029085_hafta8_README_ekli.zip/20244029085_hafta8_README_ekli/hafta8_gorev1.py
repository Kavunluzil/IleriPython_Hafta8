# Ad Soyad: Bedirhan Ündoğdu Yiğit
# Öğrenci No: 20244029085
# Tarih: 22 / 11 / 2026
# Ders: Python ile Programlama - Hafta 8 Laboratuvarı
# Açıklama: E-posta adresini sırayla belirtilen kurallara göre denetler.

def eposta_denetle(adres):
    # @ işaretini sayar, parçaları dilimler ve ilk hatanın mesajını verir.
    if adres.count("@") != 1:
        return "Tam olarak bir @ olmalı"

    konum = adres.find("@")
    kullanici = adres[:konum]
    alan = adres[konum + 1:]

    if kullanici == "":
        return "Kullanıcı adı boş olamaz"

    for karakter in kullanici:
        if not (karakter.isalnum() or karakter == "." or karakter == "_" or karakter == "-"):
            return f"Geçersiz karakter: '{karakter}'"

    if kullanici.startswith(".") or kullanici.endswith("."):
        return "Nokta ile başlayamaz/bitemez"

    if alan.count(".") == 0 or alan.startswith(".") or alan.endswith("."):
        return "Alan adı hatalı"

    if ".." in adres:
        return "Ardışık iki nokta olamaz"

    return "Geçerli"


if __name__ == "__main__":
    adres = input("E-posta: ").strip()
    print(eposta_denetle(adres))
