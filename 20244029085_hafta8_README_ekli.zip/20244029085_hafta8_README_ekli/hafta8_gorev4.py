# Ad Soyad: Bedirhan Ündoğdu Yiğit
# Öğrenci No: 20244029085
# Tarih: 22 / 11 / 2026
# Ders: Python ile Programlama - Hafta 8 Laboratuvarı
# Açıklama: Kesir sınıfının matematiksel operatörleri, çarpım ve karşılaştırma.

from math import gcd


class Kesir:
    def __init__(self, pay, payda):
        # Paydanın sıfır olmasını engeller, işareti ve sadeliği düzenler.
        if payda == 0:
            raise ZeroDivisionError("Payda sıfır olamaz")
        ortak = gcd(pay, payda)
        if payda < 0:
            ortak = -ortak
        self.pay = pay // ortak
        self.payda = payda // ortak

    def __str__(self):
        # Kesri sade metin biçiminde gösterir.
        if self.payda == 1:
            return str(self.pay)
        return f"{self.pay}/{self.payda}"

    def __add__(self, diger):
        # İki kesri toplayıp yeni sade Kesir döndürür.
        return Kesir(self.pay * diger.payda + diger.pay * self.payda,
                     self.payda * diger.payda)

    def __sub__(self, diger):
        # İki kesrin farkını yeni nesne olarak döndürür.
        return Kesir(self.pay * diger.payda - diger.pay * self.payda,
                     self.payda * diger.payda)

    def __mul__(self, diger):
        # Payları ve paydaları çarpar, sonucu sadeleştirir.
        return Kesir(self.pay * diger.pay, self.payda * diger.payda)

    def __truediv__(self, diger):
        # İkinci kesrin tersiyle çarpar, sıfıra bölmeyi engeller.
        if diger.pay == 0:
            raise ZeroDivisionError("Sıfır olan kesre bölünemez")
        return Kesir(self.pay * diger.payda, self.payda * diger.pay)

    def __eq__(self, diger):
        # Kesir değerlerini çapraz çarpımla eşitlik açısından karşılaştırır.
        if not isinstance(diger, Kesir):
            return NotImplemented
        return self.pay * diger.payda == diger.pay * self.payda

    def __lt__(self, diger):
        # İki kesri yalnızca çapraz çarpımla küçük-büyük açısından karşılaştırır.
        if not isinstance(diger, Kesir):
            return NotImplemented
        return self.pay * diger.payda < diger.pay * self.payda

    def __le__(self, diger):
        # Küçük-eşit koşulunu çapraz çarpımla hesaplar.
        if not isinstance(diger, Kesir):
            return NotImplemented
        return self.pay * diger.payda <= diger.pay * self.payda

    def __float__(self):
        # Kesrin kayan noktalı yaklaşık değerini döndürür.
        return self.pay / self.payda


if __name__ == "__main__":
    carpim = Kesir(1, 1)
    for n in range(2, 11):
        carpim = carpim * (Kesir(1, 1) - Kesir(1, n))

    # Liste kullanmadan, yalnızca '<' ile en büyük kesri bulur.
    en_buyuk = Kesir(3, 7)
    for kesir in (Kesir(5, 12), Kesir(2, 5), Kesir(4, 9), Kesir(3, 8)):
        if en_buyuk < kesir:
            en_buyuk = kesir

    print(f"Çarpım: {carpim}        En büyük: {en_buyuk}")
    print(f"Kesir(6, 8) == Kesir(3, 4) → {Kesir(6, 8) == Kesir(3, 4)}")
    print(f"Kesir(3, 4) / Kesir(3, 8) → {Kesir(3, 4) / Kesir(3, 8)}")
